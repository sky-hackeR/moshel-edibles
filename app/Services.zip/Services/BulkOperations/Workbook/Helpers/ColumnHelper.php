<?php

namespace App\Services\BulkOperations\Workbook\Helpers;

use App\Services\BulkOperations\Workbook\ColumnDefinition;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ColumnHelper
{
    /**
     * ---------------------------------------------------------
     * Get Excel Letter
     * ---------------------------------------------------------
     */
    public static function letter(
        int $index
    ): string {

        return CellHelper::letter($index);

    }

    /**
     * ---------------------------------------------------------
     * Apply Width
     * ---------------------------------------------------------
     */
    public static function applyWidth(
        Worksheet $sheet,
        ColumnDefinition $column,
        int $position
    ): void {

        if ($column->width() === null) {
            return;
        }

        $sheet
            ->getColumnDimension(
                self::letter($position)
            )
            ->setWidth(
                $column->width()
            );
    }

    /**
     * ---------------------------------------------------------
     * Apply Visibility
     * ---------------------------------------------------------
     */
    public static function applyVisibility(
        Worksheet $sheet,
        ColumnDefinition $column,
        int $position
    ): void {

        $sheet
            ->getColumnDimension(
                self::letter($position)
            )
            ->setVisible(
                !$column->hidden()
            );
    }

    /**
     * ---------------------------------------------------------
     * Apply Auto Size
     * ---------------------------------------------------------
     */
    public static function applyAutoSize(
        Worksheet $sheet,
        int $position
    ): void {

        $sheet
            ->getColumnDimension(
                self::letter($position)
            )
            ->setAutoSize(true);
    }

    /**
     * ---------------------------------------------------------
     * Apply Number Format
     * ---------------------------------------------------------
     */
    public static function applyFormat(
        Worksheet $sheet,
        ColumnDefinition $column,
        int $position
    ): void {

        if (!$column->format()) {
            return;
        }

        $sheet
            ->getStyle(
                self::letter($position)
            )
            ->getNumberFormat()
            ->setFormatCode(
                $column->format()
            );
    }

    /**
     * ---------------------------------------------------------
     * Header Cell
     * ---------------------------------------------------------
     */
    public static function headerCell(
        int $position
    ): string {

        return self::letter($position) . '1';

    }

    /**
     * ---------------------------------------------------------
     * Data Range
     * ---------------------------------------------------------
     */
    public static function dataRange(
        int $position,
        int $startRow = 2,
        int $endRow = 1000
    ): string {

        $letter = self::letter($position);

        return "{$letter}{$startRow}:{$letter}{$endRow}";

    }
}