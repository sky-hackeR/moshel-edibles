<?php

namespace App\Services\BulkOperations\Workbook;

use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class WorkbookBuilder
{
    protected WorksheetBuilder $worksheetBuilder;

    protected StyleBuilder $styleBuilder;

    protected LookupSheetBuilder $lookupSheetBuilder;

    protected ValidationBuilder $validationBuilder;

    protected CommentBuilder $commentBuilder;

    protected FormulaBuilder $formulaBuilder;

    protected ProtectionBuilder $protectionBuilder;

    public function __construct(
        WorksheetBuilder $worksheetBuilder,
        StyleBuilder $styleBuilder,
        LookupSheetBuilder $lookupSheetBuilder,
        ValidationBuilder $validationBuilder,
        CommentBuilder $commentBuilder,
        FormulaBuilder $formulaBuilder,
        ProtectionBuilder $protectionBuilder
    ) {

        $this->worksheetBuilder = $worksheetBuilder;

        $this->styleBuilder = $styleBuilder;

        $this->lookupSheetBuilder = $lookupSheetBuilder;

        $this->validationBuilder = $validationBuilder;

        $this->commentBuilder = $commentBuilder;

        $this->formulaBuilder = $formulaBuilder;

        $this->protectionBuilder = $protectionBuilder;
    }

    /**
     * ---------------------------------------------------------
     * Build Workbook
     * ---------------------------------------------------------
     */
    public function build(
        Worksheet $sheet,
        WorksheetDefinition $definition
    ): void {

        /*
        |--------------------------------------------------------------------------
        | Worksheet
        |--------------------------------------------------------------------------
        */

        $this->worksheetBuilder->build(
            $sheet,
            $definition
        );

        /*
        |--------------------------------------------------------------------------
        | Styling
        |--------------------------------------------------------------------------
        */

        $this->styleBuilder->build(
            $sheet,
            $definition
        );

        /*
        |--------------------------------------------------------------------------
        | Lookup Sheets
        |--------------------------------------------------------------------------
        */

        $this->lookupSheetBuilder->build(
            $sheet,
            $definition
        );

        /*
        |--------------------------------------------------------------------------
        | Dropdown Validation
        |--------------------------------------------------------------------------
        */

        $this->validationBuilder->build(
            $sheet,
            $definition
        );

        /*
        |--------------------------------------------------------------------------
        | Comments
        |--------------------------------------------------------------------------
        */

        $this->commentBuilder->build(
            $sheet,
            $definition
        );

        /*
        |--------------------------------------------------------------------------
        | Formulas
        |--------------------------------------------------------------------------
        */

        $this->formulaBuilder->build(
            $sheet,
            $definition
        );

        /*
        |--------------------------------------------------------------------------
        | Protection
        |--------------------------------------------------------------------------
        */

        $this->protectionBuilder->build(
            $sheet,
            $definition
        );
    }
}