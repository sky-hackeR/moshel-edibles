<?php

namespace App\Services\BulkOperations\Workbook;

class WorksheetDefinition
{
    protected string $title;

    protected ?string $subtitle = null;

    protected ?Theme $theme = null;

    /**
     * @var ColumnDefinition[]
     */
    protected array $columns = [];

    protected array $samples = [];

    protected array $instructions = [];

    protected bool $freezeHeader = true;

    protected bool $autoFilter = true;

    protected bool $protect = false;

    protected bool $hideLookups = true;

    protected bool $showInstructions = true;

    protected bool $showSample = true;

    public function __construct(string $title)
    {
        $this->title = $title;
    }

    public static function make(string $title): self
    {
        return new self($title);
    }

    public function subtitle(string $subtitle): self
    {
        $this->subtitle = $subtitle;

        return $this;
    }

    public function theme(Theme $theme): self
    {
        $this->theme = $theme;

        return $this;
    }

    /**
     * @param ColumnDefinition[] $columns
     */
    public function columns(array $columns): self
    {
        $this->columns = $columns;

        return $this;
    }

    public function addColumn(ColumnDefinition $column): self
    {
        $this->columns[] = $column;

        return $this;
    }

    public function samples(array $rows): self
    {
        $this->samples = $rows;

        return $this;
    }

    public function addSample(array $row): self
    {
        $this->samples[] = $row;

        return $this;
    }

    public function instructions(array $instructions): self
    {
        $this->instructions = $instructions;

        return $this;
    }

    public function freezeHeader(bool $value = true): self
    {
        $this->freezeHeader = $value;

        return $this;
    }

    public function autoFilter(bool $value = true): self
    {
        $this->autoFilter = $value;

        return $this;
    }

    public function protect(bool $value = true): self
    {
        $this->protect = $value;

        return $this;
    }

    public function hideLookups(bool $value = true): self
    {
        $this->hideLookups = $value;

        return $this;
    }

    public function showInstructions(bool $value = true): self
    {
        $this->showInstructions = $value;

        return $this;
    }

    public function showSample(bool $value = true): self
    {
        $this->showSample = $value;

        return $this;
    }

    /*
    |--------------------------------------------------------------------------
    | Getters
    |--------------------------------------------------------------------------
    */

    public function getTitle(): string
    {
        return $this->title;
    }

    public function getSubtitle(): ?string
    {
        return $this->subtitle;
    }

    public function getTheme(): ?Theme
    {
        return $this->theme;
    }

    /**
     * @return ColumnDefinition[]
     */
    public function getColumns(): array
    {
        return $this->columns;
    }

    public function getSamples(): array
    {
        return $this->samples;
    }

    public function getInstructions(): array
    {
        return $this->instructions;
    }

    public function shouldFreezeHeader(): bool
    {
        return $this->freezeHeader;
    }

    public function shouldAutoFilter(): bool
    {
        return $this->autoFilter;
    }

    public function shouldProtect(): bool
    {
        return $this->protect;
    }

    public function shouldHideLookups(): bool
    {
        return $this->hideLookups;
    }

    public function shouldShowInstructions(): bool
    {
        return $this->showInstructions;
    }

    public function shouldShowSample(): bool
    {
        return $this->showSample;
    }
}