<?php

namespace App\Services\BulkOperations\Workbook;

use PhpOffice\PhpSpreadsheet\NamedRange;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class LookupSheetBuilder
{
    /**
     * Hidden worksheet name.
     */
    protected string $sheetName = '_lookups';

    /**
     * Current lookup column.
     */
    protected int $column = 1;

    /**
     * Lookup cache.
     */
    protected array $ranges = [];

    /**
     * Build every lookup sheet.
     */
    public function build(
        Spreadsheet $spreadsheet,
        WorksheetDefinition $definition
    ): void {

        if (empty($definition->lookup())) {
            return;
        }

        $sheet = $this->sheet($spreadsheet);

        foreach ($definition->lookup() as $name => $values) {

            $this->createLookup(

                $spreadsheet,

                $sheet,

                $name,

                $values

            );

        }

    }

    /**
     * Get or create lookup worksheet.
     */
    protected function sheet(
        Spreadsheet $spreadsheet
    ): Worksheet {

        foreach ($spreadsheet->getWorksheetIterator() as $worksheet) {

            if ($worksheet->getTitle() === $this->sheetName) {

                return $worksheet;

            }

        }

        $sheet = new Worksheet(

            $spreadsheet,

            $this->sheetName

        );

        $spreadsheet->addSheet($sheet);

        $sheet->setSheetState(
            Worksheet::SHEETSTATE_HIDDEN
        );

        return $sheet;

    }

    /**
     * Create a named lookup.
     */
    protected function createLookup(
        Spreadsheet $spreadsheet,
        Worksheet $sheet,
        string $name,
        array $values
    ): void {

        /*
        |--------------------------------------------------------------------------
        | Already exists
        |--------------------------------------------------------------------------
        */

        if (isset($this->ranges[$name])) {
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Column Letter
        |--------------------------------------------------------------------------
        */

        $letter = $this->columnLetter(
            $this->column
        );

        /*
        |--------------------------------------------------------------------------
        | Write Values
        |--------------------------------------------------------------------------
        */

        $row = 1;

        foreach ($values as $value) {

            $sheet->setCellValue(

                $letter . $row,

                $value

            );

            $row++;

        }

        /*
        |--------------------------------------------------------------------------
        | Named Range
        |--------------------------------------------------------------------------
        */

        $range = sprintf(

            '%s!$%s$1:$%s$%d',

            $this->sheetName,

            $letter,

            $letter,

            count($values)

        );

        $spreadsheet->addNamedRange(

            new NamedRange(

                $name,

                $sheet,

                '$' . $letter . '$1:$' . $letter . '$' . count($values)

            )

        );

        $this->ranges[$name] = $range;

        $this->column++;

    }

    /**
     * Get range by name.
     */
    public function range(
        string $name
    ): ?string {

        return $this->ranges[$name] ?? null;

    }

    /**
     * Convert column index.
     */
    protected function columnLetter(
        int $column
    ): string {

        $letter = '';

        while ($column > 0) {

            $mod = ($column - 1) % 26;

            $letter = chr(65 + $mod) . $letter;

            $column = intval(($column - $mod) / 26);

        }

        return $letter;

    }
}