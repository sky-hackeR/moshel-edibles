<?php

namespace App\Services\BulkOperations\Workbook;

use App\Services\BulkOperations\Workbook\Helpers\ColumnHelper;

use PhpOffice\PhpSpreadsheet\Comment;
use PhpOffice\PhpSpreadsheet\RichText\RichText;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class CommentBuilder
{
    /**
     * Apply all worksheet comments.
     */
    public function build(
        Worksheet $sheet,
        WorksheetDefinition $definition
    ): void {

        foreach ($definition->getColumns() as $index => $column) {

            if (!$column->hasComment()) {
                continue;
            }

            $this->comment(

                $sheet,

                ColumnHelper::letter($index + 1) . '1',

                $column->comment()

            );

        }

    }

    /**
     * Create a cell comment.
     */
    protected function comment(
        Worksheet $sheet,
        string $cell,
        string $text
    ): void {

        $comment = $sheet->getComment($cell);

        $richText = new RichText();

        /*
        |--------------------------------------------------------------------------
        | Title
        |--------------------------------------------------------------------------
        */

        $title = $richText->createTextRun('Instructions');
        $title->getFont()->setBold(true);

        $richText->createText("\n\n");

        /*
        |--------------------------------------------------------------------------
        | Body
        |--------------------------------------------------------------------------
        */

        $richText->createText($text);

        $comment->setText($richText);

        /*
        |--------------------------------------------------------------------------
        | Appearance
        |--------------------------------------------------------------------------
        */

        $comment->setAuthor(config('app.name'));

        $comment->setWidth('250px');

        $comment->setHeight('120px');

        $comment->setMarginLeft('15px');

        $comment->setMarginTop('10px');

    }

    /**
     * Add workbook title comment.
     */
    public function titleComment(
        Worksheet $sheet,
        string $title,
        ?string $description = null
    ): void {

        $comment = new Comment();

        $rich = new RichText();

        $heading = $rich->createTextRun($title);

        $heading->getFont()->setBold(true);

        if ($description) {

            $rich->createText("\n\n");

            $rich->createText($description);

        }

        $comment->setText($rich);

        $comment->setAuthor(config('app.name'));

        $sheet->getComment('A1')
            ->setText($comment->getText());

    }
}