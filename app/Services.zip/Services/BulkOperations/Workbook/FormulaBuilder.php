<?php

namespace App\Services\BulkOperations\Workbook;

use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class FormulaBuilder
{
    /**
     * ---------------------------------------------------------
     * Apply Worksheet Formulas
     * ---------------------------------------------------------
     */
    public function build(
        Worksheet $sheet,
        WorksheetDefinition $definition
    ): void {

        foreach ($definition->getColumns() as $column) {

            if (!$column->hasFormula()) {
                continue;
            }

            $formula = $column->formula();

            $start = $column->startRow();

            $end = $column->endRow();

            for ($row = $start; $row <= $end; $row++) {

                $sheet
                    ->setCellValue(
                        $column->letter() . $row,
                        str_replace(
                            '{row}',
                            $row,
                            $formula
                        )
                    );

            }

        }

    }
}