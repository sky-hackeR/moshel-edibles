<?php

namespace App\Services\BulkOperations\Workbook;

use App\Services\BulkOperations\Workbook\Helpers\ColumnHelper;

use PhpOffice\PhpSpreadsheet\Style\Protection;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ProtectionBuilder
{
    /**
     * Build worksheet protection.
     */
    public function build(
        Worksheet $sheet,
        WorksheetDefinition $definition
    ): void {

        /*
        |--------------------------------------------------------------------------
        | Unlock entire sheet first
        |--------------------------------------------------------------------------
        |
        | Every cell starts unlocked.
        |
        */

        $sheet->getStyle(
            $sheet->calculateWorksheetDimension()
        )->getProtection()->setLocked(
            Protection::PROTECTION_UNPROTECTED
        );

        /*
        |--------------------------------------------------------------------------
        | Lock Header
        |--------------------------------------------------------------------------
        */

        $this->lockHeader($sheet);

        /*
        |--------------------------------------------------------------------------
        | Lock Formula Columns
        |--------------------------------------------------------------------------
        */

        foreach ($definition->getColumns() as $index => $column) {

            if (!$column->isFormula()) {
                continue;
            }

            $this->lockColumn(

                $sheet,

                ColumnHelper::letter($index + 1)

            );

        }

        /*
        |--------------------------------------------------------------------------
        | Enable Worksheet Protection
        |--------------------------------------------------------------------------
        */

        $sheet->getProtection()
            ->setSheet(true);

        /*
        |--------------------------------------------------------------------------
        | Allowed Operations
        |--------------------------------------------------------------------------
        */

        $sheet->getProtection()
            ->setSort(true);

        $sheet->getProtection()
            ->setInsertRows(true);

        $sheet->getProtection()
            ->setAutoFilter(true);

        $sheet->getProtection()
            ->setFormatCells(false);

        $sheet->getProtection()
            ->setDeleteRows(false);

        $sheet->getProtection()
            ->setInsertColumns(false);

        $sheet->getProtection()
            ->setDeleteColumns(false);

        /*
        |--------------------------------------------------------------------------
        | Optional Password
        |--------------------------------------------------------------------------
        */

        if ($definition->protectionPassword()) {

            $sheet->getProtection()
                ->setPassword(
                    $definition->protectionPassword()
                );

        }

    }

    /**
     * Lock header row.
     */
    protected function lockHeader(
        Worksheet $sheet
    ): void {

        $highestColumn = $sheet->getHighestColumn();

        $sheet->getStyle(
            "A1:{$highestColumn}1"
        )->getProtection()->setLocked(
            Protection::PROTECTION_PROTECTED
        );

    }

    /**
     * Lock an entire column.
     */
    protected function lockColumn(
        Worksheet $sheet,
        string $column,
        int $startRow = 2,
        int $endRow = 1000
    ): void {

        $sheet->getStyle(

            "{$column}{$startRow}:{$column}{$endRow}"

        )->getProtection()->setLocked(

            Protection::PROTECTION_PROTECTED

        );

    }

    /**
     * Lock an arbitrary range.
     */
    public function lockRange(
        Worksheet $sheet,
        string $range
    ): void {

        $sheet->getStyle($range)
            ->getProtection()
            ->setLocked(
                Protection::PROTECTION_PROTECTED
            );

    }

    /**
     * Unlock an arbitrary range.
     */
    public function unlockRange(
        Worksheet $sheet,
        string $range
    ): void {

        $sheet->getStyle($range)
            ->getProtection()
            ->setLocked(
                Protection::PROTECTION_UNPROTECTED
            );

    }

    /**
     * Protect an entire worksheet.
     */
    public function protectSheet(
        Worksheet $sheet,
        ?string $password = null
    ): void {

        $sheet->getProtection()
            ->setSheet(true);

        if ($password) {

            $sheet->getProtection()
                ->setPassword($password);

        }

    }

    /**
     * Remove worksheet protection.
     */
    public function unprotectSheet(
        Worksheet $sheet
    ): void {

        $sheet->getProtection()
            ->setSheet(false);

    }
}