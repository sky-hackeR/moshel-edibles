<?php

namespace App\Services\BulkOperations\Workbook;

use App\Services\BulkOperations\Workbook\Helpers\ColumnHelper;

use PhpOffice\PhpSpreadsheet\Cell\DataValidation;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ValidationBuilder
{
    /**
     * Apply every worksheet validation.
     */
    public function build(
        Worksheet $sheet,
        WorksheetDefinition $definition
    ): void {

        foreach ($definition->getColumns() as $index => $column) {

            if (empty($column->dropdownValues())) {
                continue;
            }

            $this->dropdown(

                $sheet,

                ColumnHelper::letter($index + 1),

                $column->dropdownValues()

            );

        }

    }

    /**
     * Apply dropdown validation.
     */
    protected function dropdown(
        Worksheet $sheet,
        string $column,
        array $values,
        int $startRow = 2,
        int $endRow = 1000
    ): void {

        /*
        |--------------------------------------------------------------------------
        | Excel Limitation
        |--------------------------------------------------------------------------
        |
        | Inline lists are limited to 255 characters.
        |
        | Larger lists should automatically use
        | LookupSheetBuilder.
        |
        */

        if (strlen(implode(',', $values)) > 255) {

            /*
            |--------------------------------------------------------------------------
            | Future
            |--------------------------------------------------------------------------
            |
            | WorkbookBuilder will replace this
            | with a hidden lookup sheet reference.
            |
            */

            return;

        }

        $formula = '"' . implode(',', $values) . '"';

        for ($row = $startRow; $row <= $endRow; $row++) {

            $validation = $sheet
                ->getCell($column . $row)
                ->getDataValidation();

            $validation->setType(
                DataValidation::TYPE_LIST
            );

            $validation->setErrorStyle(
                DataValidation::STYLE_STOP
            );

            $validation->setAllowBlank(
                !$this->requiredColumn($sheet, $column)
            );

            $validation->setShowDropDown(true);

            $validation->setShowInputMessage(true);

            $validation->setShowErrorMessage(true);

            $validation->setFormula1($formula);

            $validation->setPromptTitle(
                'Select a value'
            );

            $validation->setPrompt(
                'Choose one of the available options.'
            );

            $validation->setErrorTitle(
                'Invalid value'
            );

            $validation->setError(
                'Please select a value from the dropdown.'
            );

        }

    }

    /**
     * Placeholder.
     *
     * ProtectionBuilder will eventually own this.
     */
    protected function requiredColumn(
        Worksheet $sheet,
        string $column
    ): bool {

        return false;

    }

}