<?php

namespace App\Services\BulkOperations\Workbook;

use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class StyleBuilder
{
    /**
     * Apply every worksheet style.
     */
    public function build(
        Worksheet $sheet,
        WorksheetDefinition $definition
    ): void {

        $this->defaultFont($sheet);

        $this->header($sheet);

        $this->requiredColumns($sheet, $definition);

        $this->alternateRows($sheet);

        $this->columnWidths($sheet, $definition);

    }

    /**
     * Default workbook font.
     */
    public function defaultFont(
        Worksheet $sheet
    ): void {

        $sheet->getParent()
            ->getDefaultStyle()
            ->getFont()
            ->setName(Theme::FONT_FAMILY)
            ->setSize(Theme::FONT_SIZE);

    }

    /**
     * Header row.
     */
    public function header(
        Worksheet $sheet
    ): void {

        $highestColumn = $sheet->getHighestColumn();

        $range = "A1:{$highestColumn}1";

        $sheet->getStyle($range)->applyFromArray([

            'font' => [

                'bold' => true,

                'size' => Theme::HEADER_FONT_SIZE,

                'color' => [

                    'rgb' => Theme::HEADER_TEXT,

                ],

            ],

            'fill' => [

                'fillType' => Fill::FILL_SOLID,

                'startColor' => [

                    'rgb' => Theme::HEADER_BACKGROUND,

                ],

            ],

            'alignment' => [

                'horizontal' => Alignment::HORIZONTAL_CENTER,

                'vertical' => Alignment::VERTICAL_CENTER,

            ],

            'borders' => [

                'allBorders' => [

                    'borderStyle' => Border::BORDER_THIN,

                    'color' => [

                        'rgb' => Theme::BORDER,

                    ],

                ],

            ],

        ]);

        $sheet->getRowDimension(1)
            ->setRowHeight(Theme::HEADER_ROW_HEIGHT);

    }

    /**
     * Highlight required columns.
     */
    public function requiredColumns(
        Worksheet $sheet,
        WorksheetDefinition $definition
    ): void {

        $columns = $definition->getColumns();

        foreach ($columns as $index => $column) {

            if (!$column->isRequired()) {

                continue;

            }

            $letter = $this->columnLetter($index + 1);

            $sheet->getStyle("{$letter}1")
                ->getFill()
                ->setFillType(Fill::FILL_SOLID)
                ->getStartColor()
                ->setRGB(
                    Theme::REQUIRED_BACKGROUND
                );

        }

    }

    /**
     * Alternate row colours.
     */
    public function alternateRows(
        Worksheet $sheet
    ): void {

        $highestRow = max(
            100,
            $sheet->getHighestRow()
        );

        $highestColumn = $sheet->getHighestColumn();

        for ($row = 2; $row <= $highestRow; $row++) {

            $color = $row % 2 === 0

                ? Theme::TABLE_ROW_EVEN

                : Theme::TABLE_ROW_ODD;

            $sheet->getStyle(
                "A{$row}:{$highestColumn}{$row}"
            )->getFill()

                ->setFillType(Fill::FILL_SOLID)

                ->getStartColor()

                ->setRGB($color);

        }

    }

    /**
     * Apply preferred widths.
     */
    public function columnWidths(
        Worksheet $sheet,
        WorksheetDefinition $definition
    ): void {

        foreach ($definition->getColumns() as $index => $column) {

            if (!$column->preferredWidth()) {

                continue;

            }

            $sheet->getColumnDimension(

                $this->columnLetter($index + 1)

            )->setWidth(

                $column->preferredWidth()

            );

        }

    }

    /**
     * Convert index to Excel column.
     */
    protected function columnLetter(
        int $index
    ): string {

        $letter = '';

        while ($index > 0) {

            $mod = ($index - 1) % 26;

            $letter = chr(65 + $mod) . $letter;

            $index = intdiv(

                $index - $mod,

                26

            );

        }

        return $letter;

    }
}