<?php

namespace App\Exports;

class UnitTemplateExport extends BaseTemplateExport
{
    /**
     * Template definition.
     */
    public function definition(): array
    {
        return [

            /*
            |--------------------------------------------------------------------------
            | General
            |--------------------------------------------------------------------------
            */

            'title' => 'Units',

            'theme' => '6C757D',

            /*
            |--------------------------------------------------------------------------
            | Columns
            |--------------------------------------------------------------------------
            */

            'columns' => [

                'Name',

                'Symbol',

                'Unit Type',

                'Base Multiplier',

                'Base Unit',

                'Is Active',

                'Use For Purchase',

                'Use For Recipe',

            ],

            /*
            |--------------------------------------------------------------------------
            | Sample Data
            |--------------------------------------------------------------------------
            */

            'sample' => [

                'Kilogram',

                'kg',

                'mass',

                1000,

                'Gram',

                'Yes',

                'Yes',

                'Yes',

            ],

            /*
            |--------------------------------------------------------------------------
            | Required Columns
            |--------------------------------------------------------------------------
            */

            'required' => [

                'A',

                'B',

                'C',

                'D',

                'E',

            ],

            /*
            |--------------------------------------------------------------------------
            | Dropdown Lists
            |--------------------------------------------------------------------------
            */

            'dropdowns' => [

                'C' => [

                    'mass',

                    'volume',

                    'count',

                ],

                'E' => [

                    'Gram',

                    'Millilitre',

                    'Piece',

                ],

                'F' => [

                    'Yes',

                    'No',

                ],

                'G' => [

                    'Yes',

                    'No',

                ],

                'H' => [

                    'Yes',

                    'No',

                ],

            ],

            /*
            |--------------------------------------------------------------------------
            | Cell Comments
            |--------------------------------------------------------------------------
            */

            'comments' => [

                'A' => 'Display name of the unit. Example: Kilogram.',

                'B' => 'Short symbol. Example: kg, g, L, ml.',

                'C' => 'Choose the measurement category.',

                'D' => 'Conversion factor to the base unit.',

                'E' => 'Canonical unit used by the conversion engine.',

                'F' => 'Choose whether this unit is active.',

                'G' => 'Can this unit be used when purchasing stock?',

                'H' => 'Can this unit be used inside recipes?',

            ],

            /*
            |--------------------------------------------------------------------------
            | Header Instructions
            |--------------------------------------------------------------------------
            */

            'instructions' => [

                'A' => 'Unit names should be unique.',

                'B' => 'Symbols should be unique within the same unit type.',

                'C' => 'Choose Mass, Volume or Count.',

                'D' => 'Examples: Gram = 1, Kilogram = 1000, Milligram = 0.001.',

                'E' => 'Choose the correct canonical base unit.',

                'F' => 'Yes = Active, No = Inactive.',

                'G' => 'Controls availability during stock purchases.',

                'H' => 'Controls availability inside recipes.',

            ],

            /*
            |--------------------------------------------------------------------------
            | Column Widths
            |--------------------------------------------------------------------------
            */

            'widths' => [

                'A' => 28,

                'B' => 15,

                'C' => 18,

                'D' => 20,

                'E' => 20,

                'F' => 15,

                'G' => 20,

                'H' => 20,

            ],

            /*
            |--------------------------------------------------------------------------
            | Number Formats
            |--------------------------------------------------------------------------
            */

            'formats' => [

                'D' => '#,##0.0000',

            ],

        ];
    }
}