<?php

namespace App\Exports;

use App\Models\Product;
use App\Models\Ingredient;
use App\Models\Unit;

class RecipeTemplateExport extends BaseTemplateExport
{
    /**
     * Template definition.
     */
    public function definition(): array
    {
        return [

            /*
            |--------------------------------------------------------------------------
            | General
            |--------------------------------------------------------------------------
            */

            'title' => 'Recipes',

            'theme' => 'FFC107',

            /*
            |--------------------------------------------------------------------------
            | Columns
            |--------------------------------------------------------------------------
            */

            'columns' => [

                'Recipe',

                'Product',

                'Ingredient',

                'Quantity',

                'Unit',

                'Is Active',

                'Note',

            ],

            /*
            |--------------------------------------------------------------------------
            | Sample Data
            |--------------------------------------------------------------------------
            */

            'sample' => [

                'Fried Rice',

                'Fried Rice',

                'Rice',

                500,

                'Gram',

                'Yes',

                'Standard recipe',

            ],

            /*
            |--------------------------------------------------------------------------
            | Required Columns
            |--------------------------------------------------------------------------
            */

            'required' => [

                'A',

                'B',

                'C',

                'D',

                'E',

            ],

            /*
            |--------------------------------------------------------------------------
            | Dropdown Lists
            |--------------------------------------------------------------------------
            */

            'dropdowns' => [

                'B' => Product::query()
                    ->where('is_active', true)
                    ->orderBy('name')
                    ->pluck('name')
                    ->toArray(),

                'C' => Ingredient::query()
                    ->where('is_active', true)
                    ->orderBy('name')
                    ->pluck('name')
                    ->toArray(),

                'E' => Unit::query()
                    ->where('is_active', true)
                    ->orderBy('name')
                    ->pluck('name')
                    ->toArray(),

                'F' => [

                    'Yes',

                    'No',

                ],

            ],

            /*
            |--------------------------------------------------------------------------
            | Cell Comments
            |--------------------------------------------------------------------------
            */

            'comments' => [

                'A' => 'Recipe name. Multiple rows can share the same recipe name.',

                'B' => 'Select the product this recipe belongs to.',

                'C' => 'Choose an ingredient used in the recipe.',

                'D' => 'Enter the quantity required.',

                'E' => 'Choose the measurement unit.',

                'F' => 'Set whether this recipe is active.',

                'G' => 'Optional notes or preparation instructions.',

            ],

            /*
            |--------------------------------------------------------------------------
            | Header Instructions
            |--------------------------------------------------------------------------
            */

            'instructions' => [

                'A' => 'Rows with the same recipe name will be grouped into one recipe during import.',

                'B' => 'Only active products can be selected.',

                'C' => 'Only active ingredients can be selected.',

                'D' => 'Quantity must be greater than zero.',

                'E' => 'Choose a valid measurement unit.',

                'F' => 'Yes = Active, No = Inactive.',

                'G' => 'Optional field.',

            ],

            /*
            |--------------------------------------------------------------------------
            | Column Widths
            |--------------------------------------------------------------------------
            */

            'widths' => [

                'A' => 30,

                'B' => 30,

                'C' => 30,

                'D' => 15,

                'E' => 20,

                'F' => 15,

                'G' => 40,

            ],

            /*
            |--------------------------------------------------------------------------
            | Number Formats
            |--------------------------------------------------------------------------
            */

            'formats' => [

                'D' => '#,##0.000',

            ],

        ];
    }
}