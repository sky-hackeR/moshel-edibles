<?php

namespace App\Exports;

use App\Models\Ingredient;
use App\Models\Unit;

class StockTemplateExport extends BaseTemplateExport
{
    /**
     * Template definition.
     */
    public function definition(): array
    {
        return [

            /*
            |--------------------------------------------------------------------------
            | General
            |--------------------------------------------------------------------------
            */

            'title' => 'Stock In',

            'theme' => '17A2B8',

            /*
            |--------------------------------------------------------------------------
            | Columns
            |--------------------------------------------------------------------------
            */

            'columns' => [

                'Purchase Date',

                'Supplier',

                'Ingredient',

                'Quantity',

                'Unit',

                'Unit Price',

                'Note',

            ],

            /*
            |--------------------------------------------------------------------------
            | Sample Data
            |--------------------------------------------------------------------------
            */

            'sample' => [

                '2026-07-30',

                'Fresh Foods Ltd',

                'Rice',

                50,

                'Kilogram',

                52000,

                'Weekly purchase',

            ],

            /*
            |--------------------------------------------------------------------------
            | Required Columns
            |--------------------------------------------------------------------------
            */

            'required' => [

                'A',

                'C',

                'D',

                'E',

                'F',

            ],

            /*
            |--------------------------------------------------------------------------
            | Dropdown Lists
            |--------------------------------------------------------------------------
            */

            'dropdowns' => [

                'C' => Ingredient::query()
                    ->where('is_active', true)
                    ->orderBy('name')
                    ->pluck('name')
                    ->toArray(),

                'E' => Unit::query()
                    ->where('is_active', true)
                    ->orderBy('name')
                    ->pluck('name')
                    ->toArray(),

            ],

            /*
            |--------------------------------------------------------------------------
            | Cell Comments
            |--------------------------------------------------------------------------
            */

            'comments' => [

                'A' => 'Enter the purchase date using YYYY-MM-DD format.',

                'B' => 'Supplier name (optional).',

                'C' => 'Choose an ingredient from the dropdown.',

                'D' => 'Purchased quantity.',

                'E' => 'Select the purchase unit.',

                'F' => 'Cost per selected unit.',

                'G' => 'Optional purchase notes.',

            ],

            /*
            |--------------------------------------------------------------------------
            | Header Instructions
            |--------------------------------------------------------------------------
            */

            'instructions' => [

                'A' => 'Example: 2026-07-30',

                'B' => 'Optional field.',

                'C' => 'Only active ingredients can be selected.',

                'D' => 'Quantity must be greater than zero.',

                'E' => 'Choose a valid unit.',

                'F' => 'Enter numbers only. Do not include commas or currency symbols.',

                'G' => 'Optional field.',

            ],

            /*
            |--------------------------------------------------------------------------
            | Column Widths
            |--------------------------------------------------------------------------
            */

            'widths' => [

                'A' => 18,

                'B' => 30,

                'C' => 30,

                'D' => 15,

                'E' => 20,

                'F' => 18,

                'G' => 40,

            ],

            /*
            |--------------------------------------------------------------------------
            | Number Formats
            |--------------------------------------------------------------------------
            */

            'formats' => [

                'D' => '#,##0.000',

                'F' => '#,##0.00',

            ],

        ];
    }
}